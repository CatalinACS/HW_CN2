#include "7_seg.h"
void seven_seg (bool refresh_signal,ap_uint<8> input, ap_uint<8> &seg_seven_data, ap_uint<4> &seg_seven_enable);
