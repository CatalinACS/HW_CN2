#pragma once
#include "clk_seg_seven.h"
void clk_seg_seven(bool& out1);
