#include <ap_int.h>

#define SIGNAL_PERIOD 200000
